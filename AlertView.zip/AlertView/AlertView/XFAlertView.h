//
//  XFAlertView.h
//  AlertView
//
//  Created by Sheffi on 16/11/11.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#define SCREEN_H ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_W ([[UIScreen mainScreen] bounds].size.width)
#define RGBColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]
#define RGBColorAlpha(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define TitleTextColor RGBColor(54, 54, 54)  // 标题颜色
#define CancelButtonText @"取消"
#define ConfirmButtonText @"确定"
#define ConfirmButtonTextColor RGBColor(217, 28, 26)
#define CancelButtonTextColor RGBColor(149, 149, 149)
#define AlertViewColor RGBColorAlpha(0, 0, 0, 0.3)


#import <UIKit/UIKit.h>
typedef enum : NSUInteger {
    AlertActionCancel = 0,
    AlertActionConfirm,
} AlertAction;

/**< 回调的方法  */
//typedef void(^TapAlertButtonBlock)(NSUInteger buttonIndex);

@class XFAlertView;
/**< 协议 */
@protocol XFAlertViewDelegate <NSObject>

@optional
//点击alert上的button
-(void)alertActionWith:(AlertAction)buttonIndex;

@end

@interface XFAlertView : UIView
/**< 底部View */
@property (strong, nonatomic) UIView *bottomView;
/**< 标题内容 */
@property (strong, nonatomic) UILabel *titleLabel;
/**< 取消按钮 */
@property (strong, nonatomic) UIButton *cancelButton;
/**< 确定按钮 */
@property (strong, nonatomic) UIButton *confirmButton;

@property (nonatomic,assign) id<XFAlertViewDelegate> delegate ;

+(XFAlertView *)alertShowInViewController:(UIViewController *)showVC andTitle:(NSString *)title andCancelButtonTitle:(NSString *)cancelButtonTitle andConfirmButtonTitle:(NSString *)confirmButtonTitle;

//+(void)setAlertActionForBlock:(TapAlertButtonBlock)block;
@end
