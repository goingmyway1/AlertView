//
//  ViewController.h
//  AlertView
//
//  Created by Sheffi on 16/11/11.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

