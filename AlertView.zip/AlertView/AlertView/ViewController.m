//
//  ViewController.m
//  AlertView
//
//  Created by Sheffi on 16/11/11.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import "ViewController.h"
#import "XFAlertView.h"
@interface ViewController ()<XFAlertViewDelegate>
@property (strong, nonatomic) UIButton *button;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _button = [[UIButton alloc]initWithFrame:CGRectMake(10, 10, 100, 30)];
    [_button setTitle:@"show" forState:UIControlStateNormal];
    [_button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [self.view addSubview:_button];
    [_button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
//    [XFAlertView setAlertActionForBlock:^(NSUInteger buttonIndex) {
//        switch (buttonIndex) {
//            case AlertActionCancel:
//            {
//                NSLog(@"取消1");
//            }
//                break;
//            case AlertActionConfirm:
//            {
//                NSLog(@"确定2");
//            }
//                break;
//            default:
//                break;
//        }
//
//    }];
}
-(void)buttonAction:(UIButton *)sender{
    XFAlertView *alertView = [XFAlertView alertShowInViewController:self andTitle:@"jkkksdjfksdjfkasfjsaj" andCancelButtonTitle:nil andConfirmButtonTitle:nil];
    alertView.delegate = self;
}
-(void)alertActionWith:(AlertAction)buttonIndex{
    switch (buttonIndex) {
        case AlertActionCancel:
        {
            NSLog(@"取消");
        }
            break;
        case AlertActionConfirm:
        {
            NSLog(@"确定");
        }
            break;
        default:
            break;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
