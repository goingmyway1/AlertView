//
//  main.m
//  AlertView
//
//  Created by Sheffi on 16/11/11.
//  Copyright © 2016年 Sheffi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
